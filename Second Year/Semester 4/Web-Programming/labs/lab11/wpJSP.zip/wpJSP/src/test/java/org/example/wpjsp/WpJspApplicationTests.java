package org.example.wpjsp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WpJspApplicationTests {

    @Test
    void contextLoads() {
    }

}
